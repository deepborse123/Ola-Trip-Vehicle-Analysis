# Ola-Dashboard
This is a dashboard using Power Bi for analysing everything about ola 

# For Every aspect has a different dashboard so this is a very usefull dashboard to analyse about the ola 

# steps :-
* Clean the data using excel
* Transform the data using Power Bi
* Create DAX and Measure queries
* Data Vizulization using Canvas Background and many other things
